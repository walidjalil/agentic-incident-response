#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 22:52:55 2026

@author: walidajalil
"""

from mcp import Client, StdioServerParameters
from mcp.types import TextContent
import anyio


server_params = StdioServerParameters(command="python", args=["mcp_server.py"])


async def get_tool_definitions(client):
    # Discovery
    tool_definitions = []

    result = await client.list_tools()

    for tool in result.tools:
        tool_definition = {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.input_schema,
            },
        }
        tool_definitions.append(tool_definition)
    return tool_definitions


async def call_mcp_tool(client, tool_name, arguments):
    blocks = []
    # Execution
    result = await client.call_tool(tool_name, arguments)
    for block in result.content:
        if isinstance(block, TextContent):
            blocks.append(block.text)
    blocks_string = "\n".join(blocks)

    return blocks_string


async def main():
    async with Client(server_params) as client:
        tool_definitions = await get_tool_definitions(client)
        print(tool_definitions)

        result = await call_mcp_tool(
            client,
            "search_logs",
            {"query": "ERROR", "limit": 5},
        )

        print(result)


if __name__ == "__main__":
    anyio.run(main)

    # result = anyio.run(
    #     call_mcp_tool,
    #     "search_runbooks",
    #     {
    #         "query": "What should I investigate when the database reaches its maximum connection limit?",
    #         "top_k": 3,
    #     },
    # )

    # print(result)
