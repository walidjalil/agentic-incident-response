#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 16 20:43:46 2026

@author: walidajalil
"""

from mcp import Client
from mcp_client import server_params, get_tool_definitions, call_mcp_tool
import anyio
import os
import requests
import time
import json
import utils


api_key = os.getenv("RUNPOD_API_KEY")
endpoint_id = os.getenv("RUNPOD_ENDPOINT_ID")


url = f"https://api.runpod.ai/v2/{endpoint_id}/runsync"

headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
}

# Chat Completions tool schema (vLLM/OpenAI-compatible format).
# Chat Completions API is slightly different than Responses API. "type": "function" part is slightly different.


def ask_llm(messages, tool_definitions=None):
    data = {
        "input": {
            "route": "/v1/chat/completions",
            "method": "POST",
            "body": {
                "model": "qwen/qwen3-8b",
                "messages": messages,
                "tools": tool_definitions,
                "max_tokens": 6000,
                "temperature": 0.2,
                "chat_template_kwargs": {"enable_thinking": True},
            },
        }
    }

    response = requests.post(
        url,
        headers=headers,
        json=data,
    )

    result = response.json()

    job_id = result["id"]
    status_url = f"https://api.runpod.ai/v2/{endpoint_id}/status/{job_id}"

    while True:
        status_response = requests.get(
            status_url,
            headers=headers,
        )

        # Stop if the HTTP request itself failed (e.g. 404).
        status_response.raise_for_status()

        status_data = status_response.json()
        status = status_data["status"]

        print("\nCurrent status:", status)

        # Code block to return the message if status is completed.
        if status == "COMPLETED":
            message = status_data["output"][0]["choices"][0]["message"]
            return message

        # Stop polling if RunPod reports a failed job.
        if status in ("FAILED", "CANCELLED", "TIMED_OUT"):
            print("RunPod error:", status_data)
            raise RuntimeError(f"RunPod job {status}")

        time.sleep(10)


def prepare_context(prompt):
    # Find the latest assistant message containing tool calls.
    last_tool_call_idx = max(
        (
            i
            for i, msg in enumerate(prompt)
            if msg["role"] == "assistant" and msg.get("tool_calls")
        ),
        default=-1,
    )

    # Only compress tool results from earlier iterations.
    old_indices = {
        i
        for i, msg in enumerate(prompt)
        if msg["role"] == "tool" and i < last_tool_call_idx
    }

    messages = []

    for i, msg in enumerate(prompt):
        if i in old_indices and isinstance(msg.get("content"), str):
            content = msg["content"]

            if len(content) > 3000:
                content = (
                    content[:1500]
                    + "\n\n[Older log output omitted]\n\n"
                    + content[-1500:]
                )

            # Create a copy. Do not change the original.
            messages.append({**msg, "content": content})
        else:
            messages.append(msg)

    return messages


async def run_agent(prompt):
    async with Client(server_params) as client:
        tool_definitions = await get_tool_definitions(client)

        #     messages = [
        #         {
        #             "role": "system",
        #             "content": "Use the available tools when needed.",
        #         },
        #         {
        #             "role": "user",
        #             "content": """The API has become significantly slower and is returning intermittent 5xx errors.
        # Investigate the incident, determine the most likely root cause, and explain what evidence supports your conclusion.
        # Use any available tools or documentation that would help.""",
        #         },
        #     ]

        max_agentic_iterations = 10
        agentic_iterations = 0

        while True:
            # Stop safely if the agent reaches the iteration limit.
            if agentic_iterations >= max_agentic_iterations:
                prompt.append(
                    {
                        "role": "user",
                        "content": "Maximum agent iterations reached. Give your best final answer using the information gathered so far.",
                    }
                )
                context = prepare_context(prompt)

                for msg in context:
                    if msg["role"] == "tool":
                        print(
                            "Tool result length:",
                            len(msg["content"]),
                            "Contains lost:",
                            "lost" in msg["content"].lower(),
                        )

                print(
                    "Original context:",
                    sum(len(str(m)) for m in prompt),
                    "characters",
                )
                print(
                    "Prepared context:",
                    sum(len(str(m)) for m in context),
                    "characters",
                )

                final_answer = ask_llm(context, [])

                print("\nAgent stopped: maximum agent iterations reached.")
                print("Final answer:")
                print(utils.remove_thinking(final_answer["content"]))
                return utils.remove_thinking(final_answer["content"])

            agentic_iterations += 1

            context = prepare_context(prompt)

            for msg in context:
                if msg["role"] == "tool":
                    print(
                        "Tool result length:",
                        len(msg["content"]),
                        "Contains lost:",
                        "lost" in msg["content"].lower(),
                    )

            print(
                "Original context:",
                sum(len(str(m)) for m in prompt),
                "characters",
            )
            print(
                "Prepared context:",
                sum(len(str(m)) for m in context),
                "characters",
            )

            answer = ask_llm(context, tool_definitions)
            prompt.append(answer)

            if answer.get("tool_calls"):
                for a in answer["tool_calls"]:
                    tool_name = a["function"]["name"]

                    tool_args_dict = json.loads(a["function"]["arguments"])

                    print("\nQwen chose: ", tool_name)
                    print("Arguments:", tool_args_dict)

                    tool_result = await call_mcp_tool(
                        client,
                        tool_name,
                        tool_args_dict,
                    )
                    # print("\nTool result:\n")
                    # print(tool_result)

                    # Native tool calling can call on multiple functions in the same answer. Make sure you REMEMBER that!
                    new_message = {
                        "role": "tool",
                        "tool_call_id": a["id"],
                        "content": tool_result,
                    }
                    prompt.append(new_message)

            # If no tool call is returned, treat the response as final.
            else:
                print("\n")
                final_answer = utils.remove_thinking(answer["content"])
                print(final_answer)
                return final_answer


async def main():
    prompt = [
        {
            "role": "system",
            "content": "Use the available tools when needed.",
        },
        {
            "role": "user",
            "content": """Investigate Hadoop application "application_1445062781478_0012" using the available tools.
    
    Classify the application as exactly one of:
    - Normal
    - Machine down
    - Network disconnection
    - Disk full
    
    Search instructions:
    - BM25 uses lexical matching, so use short, focused search queries.
    - Perform at least two separate searches targeting different failure indicators.
    - Search separately for node availability, container failures, network connectivity, and storage problems.
    - Include at least one query targeting node availability, using terms such as "node" or "lost".
    - Do not combine all failure categories into a single BM25 query.
    - Relevant diagnostic information may appear in INFO-level logs, not only ERROR-level logs.
    - Distinguish observed symptoms from the most likely root cause.
    
    Return your final answer as valid JSON with exactly these fields:
    - "label": one of "Normal", "Machine down", "Network disconnection", "Disk full"
    - "explanation": a short explanation of the evidence""",
        },
    ]

    result = await run_agent(prompt)
    return result


if __name__ == "__main__":
    final_answer = anyio.run(main)
